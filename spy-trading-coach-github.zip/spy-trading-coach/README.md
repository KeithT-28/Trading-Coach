# SPY Trading Coach (Educational Paper Trading)

A beginner-friendly, GitHub Pages-compatible web app for learning how two 15-minute equity strategies work:

- Trend-following pullbacks
- Breakouts and retests

It draws 20/50 EMAs, identifies confirmed swing highs/lows as candidate resistance/support, runs a simplified long-only historical simulation, and explains the latest trend and levels.

## Important
- This is an educational prototype, not financial advice or a validated strategy.
- No live orders are placed.
- Demo data is synthetic and is not actual SPY history.
- For meaningful analysis, upload real SPY 15-minute OHLCV CSV data from a data provider.
- Backtest fills are simplified. The simulation uses one share, commission and slippage assumptions, and assumes the stop is hit first if a bar touches both stop and target.
- Do not interpret demo results as evidence of profitability.

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a modern browser. An internet connection is needed for the Chart.js CDN.
3. Upload an OHLCV CSV, or click **Load demo data** to explore the interface.

## Publish with GitHub Pages
1. Create a GitHub repository, e.g. `spy-trading-coach`.
2. Upload `index.html` and `README.md` to the repository root.
3. In the repository, go to **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for the Pages URL to appear in the Pages settings. Open that URL on iPhone or computer.

## CSV format
Headers should include `time` (or `timestamp` / `date`), `open`, `high`, `low`, `close`, and optionally `volume`. Header names are case-insensitive. The app needs at least 60 rows. Use consistent timestamps and ascending time order. Avoid mixing time zones or bar intervals.

Example header:
```csv
time,open,high,low,close,volume
2026-01-05 09:30,600.10,601.20,599.80,600.90,123456
```

## Current rule definitions
- Trend filter: close above 50 EMA and 20 EMA above 50 EMA.
- Pullback: low touches or falls below 20 EMA, then candle closes above 20 EMA, above previous close, and bullish.
- Breakout: candle closes above the last confirmed swing resistance.
- Retest: within 10 bars, price returns near the breakout level and closes above it on a bullish candle.
- Swing points: pivot high/low must be greater/less than the surrounding `N` bars on both sides. The level only becomes known after the right-side confirmation bars have elapsed.
- Stop: lowest low of the recent five bars minus 0.2 ATR.
- Target: entry plus `R multiple × risk`.
- Long-only, one-share prototype. Compare the strategies separately over the same date range before drawing conclusions.

## Known limitations / next steps
- Add bearish setups and position sizing by account risk.
- Cluster nearby pivots into support/resistance zones and score reactions.
- Add a proper independent strategy comparison and drawdown metrics.
- Improve trade simulation for intrabar execution, market sessions, gaps and data quality.
- Add CSV export for the trade journal and a per-signal explanation panel.
